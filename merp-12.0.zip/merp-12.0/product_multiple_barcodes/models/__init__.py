# Copyright 2019 VentorTech OU
# Part of Ventor modules. See LICENSE file for full copyright and licensing details.

from . import product_barcode_multi
from . import product_template
from . import product_product
